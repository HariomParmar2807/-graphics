#include <graphics.h>
#include <bits/stdc++.h>
using namespace std;
#include <math.h>
float f(int x);

int main()
{
int x,y;
int a=4;
int gd = DETECT, gm;

initgraph(&gd, &gm, " ");



for(x=0;x<1000;x++)
{
y=f(x);
putpixel(x+300, 175-y,GREEN);
putpixel(x+300, 175+y,GREEN);
}
delay(5000);
closegraph();
return 0;
}

float f(int x)
{
return 2*sqrt(4*x);
}